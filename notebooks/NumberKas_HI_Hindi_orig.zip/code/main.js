var Abacus={},Utils ={};
Utils.Path='';
var Language,audioCounter=0,globalCounter=1,timerForFunCall_CountBalls1,timerForFunCall_CountBalls2,imageChangetimer,startTime,firstTimeAnsWrong=false;
Utils.mobileDeviceFlag=false;
$(document).ready(function()
{
	// check whether it is Tablet or Desktop
	$("#coverPage,#gamePage").hide();
	$(".se-pre-con").show();
	if(navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i))
		Utils.mobileDeviceFlag=true;
	if(Utils.mobileDeviceFlag)
 		Utils.Path=Android.getMediaPath("NumberKas");  
	
	setTimeout(function(){
		Language="Hindi";
		console.log(Language);
		//setFontFamilyForLang(langWiseJSON[Language].font);
 		Abacus.setImagesAndLabels();   
  		Abacus.registerEventListener(); 
		$(".se-pre-con").fadeOut("slow");
  	},100);
});

// set font family to body for selected lang. if required.
setFontFamilyForLang=function(fontFilePath){
	var newStyle = "<style>"+
						"@font-face {  "+
							"font-family: 'CustomFontFamily';"  +
    						"src: url('"+fontFilePath+"') format('truetype');"+
    						"}  </style>";
    $("head").append(newStyle);
    $("body").css("font-family","CustomFontFamily");						
}

//Select JSON data for lang. & set all images
Abacus.setImagesAndLabels=function(){
  	audioTag = new Audio();
  	audioTag1 = new Audio();
  	// select data from JSON as per selected lang.
  	Abacus.numberTextJSON=langWiseJSON[Language].numberTextJSON;
	Abacus.numberSoundsJSON=langWiseJSON[Language].numberSoundsJSON;
	
	$("body").css({'backgroundImage':'url('+Utils.Path+langWiseJSON[Language].coverPage+')'});

	$('#levelPage,#gamePage').hide();
	$("#levelOneImage").prop("src",Utils.Path+"img/level1.png");
	$("#levelTwoImage").prop("src",Utils.Path+"img/level2.png");
	$("#levelThreeImage").prop("src",Utils.Path+"img/level3.png");
	$(".homeIcon").prop("src",Utils.Path+"img/home.png");  
    $(".playIcon").prop("src",Utils.Path+"img/play.png");
	$(".nextIcon").prop("src",Utils.Path+"img/next.png");  
	$(".prathamlogo").prop("src",Utils.Path+"img/prathamlogo.png");  
	$(".ballFor1").prop("src",Utils.Path+"img/ballFor1.png");
	$(".ballFor10").prop("src",Utils.Path+"img/ballFor10.png");
	$(".ballFor100").prop("src",Utils.Path+"img/ballFor100.png");
	$(".ballFor1000").prop("src",Utils.Path+"img/ballFor1000.png");
    $(".kakaji").prop("src",Utils.Path+"img/pointing.png");
	$(".soundIcon").prop("src",Utils.Path+"img/Sound.png"); 
	$("#coverPage").show();
}

// register all on click event listener
Abacus.registerEventListener=function(){
	$("#levelOneImage").on("click",function(){ Abacus.level=1; Abacus.createAbacusTemplateForRange(1,10); });
	$("#levelTwoImage").on("click",function(){ Abacus.level=2; Abacus.createAbacusTemplateForRange(10,100); });
	$("#levelThreeImage").on("click",function(){ Abacus.level=3; Abacus.createAbacusTemplateForRange(100,1000); });
	$(".nextIcon").on("click",function(){
    	$(".nextIcon").addClass("animated pulse");
    	setTimeout(function(){$(".nextIcon").removeClass("animated pulse");},700);
    	Abacus.selectRandomNumberFromRange();
  	});
  	$(".homeIcon,.playIcon").on("click",Abacus.showLevelPage);
}

//when click on Play or Home ,display level page
Abacus.showLevelPage=function(){
	$("#AbacusGameMainDiv").css("background-image","url('"+Utils.Path+"img/BodyBG.jpg')");
 	$('#levelPage').show(); 
    $("#coverPage,#gamePage").hide();
    $('#abacusPad').empty();
    audioTag.pause();
}

// create template with numbers as headers & and attach respective number of balls images below Number
Abacus.createAbacusTemplateForRange=function(startNo,endNo){
	var abacusTemplate='',TotalNoOfColumn=10,NumberOnColumn=startNo;
	Abacus.StartNoOfLevel=startNo;
	Abacus.EndNoOfLevel=endNo;
	for(var columnNo=1;columnNo<=TotalNoOfColumn;columnNo++){
		abacusTemplate+='<div id=column'+columnNo+' class="column col-lg-1 col-md-1 col-sm-1 col-xs-1" >'+
	                    '<div class="abacusNumber row" onclick="Abacus.checkAnswer('+columnNo+');">'+NumberOnColumn+'</div>';
		for(var BallsRow=1;(BallsRow<=columnNo && BallsRow<=5) ;BallsRow++){
	    	if(columnNo>5 && (columnNo-BallsRow)>=5)
	    		abacusTemplate+='<div class="ballsInColumn_Div row">'+
	                        '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 Col1BallsDiv" style="padding:0px;">'+
	                       '<img class=" animated ballsInColumn ballNo'+BallsRow+'" src="'+Utils.Path+'img/ballFor'+startNo+'.png"></div>'+
	                       '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="padding:0px;">'+
	                       '<img class="animated ballsInColumn  ballNo'+(BallsRow+5)+'" src="'+Utils.Path+'img/ballFor'+startNo+'.png"></div>'+
	                    '</div>';
	    	else
	    		abacusTemplate+='<div class="ballsInColumn_Div row">'+
	                      '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 Col1BallsDiv" style="padding:0px;">'+
	                       '<img class="animated ballsInColumn ballNo'+BallsRow+'" src="'+Utils.Path+'img/ballFor'+startNo+'.png"></div>'+
	                    '</div>';
		}
		if(columnNo==10)
		   	abacusTemplate+='<div class="row BallForRoundup">'+
		                      '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="padding:0px;">'+
		                       '<img class="ballsInColumn " src="'+Utils.Path+'img/ballFor'+(startNo*10)+'.png"></div>'+
		                    '</div>';
	    abacusTemplate+='</div>';   
		NumberOnColumn+=startNo;
	}
	$('#abacusPad').append(abacusTemplate);
	$('.column >.ballsInColumn_Div').hide();
	$('.column >.BallForRoundup').hide();
	$(".abacusNumber").css("background-image","url('"+Utils.Path+"img/ButtonBGForBall"+startNo+".png')");
	// set size of ball as per value of ball
	if(Abacus.StartNoOfLevel==1)
		$(".ballsInColumn").addClass("BallFor1WidthInAbacusPad");
	if(Abacus.StartNoOfLevel==10)
		$(".ballsInColumn").addClass("BallFor10WidthInAbacusPad");
	if(Abacus.StartNoOfLevel==100)
		$(".ballsInColumn").addClass("BallFor100WidthInAbacusPad");
	$('#levelPage').hide();
	$('#gamePage').show();
	Abacus.selectRandomNumberFromRange();
}

// select a random from the selected range , on which player has to click. 
Abacus.selectRandomNumberFromRange=function(){
	firstTimeAnsWrong=false;
	var d=new Date();
   	startTime=d.getDate()+"-"+(d.getMonth()+1)+"-"+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();

	audioTag.pause();
	audioTag.src=Utils.Path+"sounds/ting.mp3";
    audioTag.play();
    audioTag.onended=function(){
        audioTag.pause();
    }
	clearTimeout(timerForFunCall_CountBalls1);
	clearTimeout(timerForFunCall_CountBalls2);
    clearTimeout(imageChangetimer);
    $('.ballsInColumn_Div,.BallForRoundup').hide();
	$(".kakaji").prop("src",Utils.Path+"img/pointing.png");
    $(".abacusNumber").css("pointer-events", "auto");
	//syntax : Math.floor(Math.random() * (max - min + 1)) + min
	var oneToTenDigit=Math.floor(Math.random() * (10 - 1 + 1)) + 1; // in range(1,9)
	var NewRandomNumber=oneToTenDigit*Abacus.StartNoOfLevel;
	// if current selected No. & previous No. is same ,then again select another randomNumber to avoid repeating  
//	if(Abacus.randomNumber!=NewRandomNumber){
		Abacus.randomNumber=NewRandomNumber;
		$(".circleNumber").html(Abacus.numberTextJSON[Abacus.randomNumber]).addClass("blink_me");		
//	}
//	else
//		Abacus.selectRandomNumberFromRange();
	console.log(Abacus.randomNumber);		
}

//check ,whether asked No. & Preseed No. is same. if same Count all Balls In that Column one by one
Abacus.checkAnswer=function(pressedColumnNo){
	var scoredMarks,totalMarks=10;
	audioTag.pause();
    clearTimeout(timerForFunCall_CountBalls1); 	
    clearTimeout(timerForFunCall_CountBalls2);
    clearTimeout(imageChangetimer);
    if(Abacus.randomNumber!=$('#column'+pressedColumnNo+'>.abacusNumber').text()){
		$(".kakaji").prop("src",Utils.Path+"img/Angry.png"); 
		audioTag.src=Utils.Path+"sounds/BuzzerWrong.mp3";
		audioTag.play();
		imageChangetimer=setTimeout(function(){$(".kakaji").prop("src",Utils.Path+"img/pointing.png");},900);
		if(!firstTimeAnsWrong){
			scoredMarks=0;
	    	console.log(Abacus.randomNumber,scoredMarks,totalMarks,Abacus.level,startTime);
			if(Utils.mobileDeviceFlag)
				Android.addScore(resId,Abacus.randomNumber,scoredMarks,totalMarks,Abacus.level,startTime);
        	firstTimeAnsWrong=true;
        }
    }	
	else{
		scoredMarks=10;
	    console.log(Abacus.randomNumber,scoredMarks,totalMarks,Abacus.level,startTime);
		if(Utils.mobileDeviceFlag)
			Android.addScore(resId,Abacus.randomNumber,scoredMarks,totalMarks,Abacus.level,startTime);
        clearTimeout(imageChangetimer);
        $(".abacusNumber").css("pointer-events", "none");
		$(".circleNumber").removeClass("blink_me animated slideInDown");
		$(".kakaji").prop("src",Utils.Path+"img/Happy.png"); 
		
        audioTag.src=Utils.Path+langWiseJSON[Language].correctSound[Math.floor(Math.random()*langWiseJSON[Language].correctSound.length)];
		audioTag.play();
		$('.ballsInColumn_Div').hide();
		$('.BallForRoundup').hide();
		$('#column'+pressedColumnNo+'>.ballsInColumn_Div > div > .ballsInColumn').removeClass("zoomIn");
		$('#column'+pressedColumnNo+'>.ballsInColumn_Div').show();
		$('#column'+pressedColumnNo+'>.BallForRoundup').hide();
		Abacus.currentColumn=pressedColumnNo;
 		globalCounter=1;  
		/*audioTag1.onended=function(){
     	 	audioTag1.pause();
			timerForFunCall_CountBalls1=setTimeout(function(){
								Abacus.CountBallsInColumn(Abacus.currentColumn);
		    },500);
		}*/
		timerForFunCall_CountBalls1=setTimeout(function(){
     			Abacus.CountBallsInColumn(Abacus.currentColumn);
	     	},1800);
	}
}

//count all the balls in column one by one ,with sound
Abacus.CountBallsInColumn=function(columnNo){
    var ballsInColumn=$('#column'+columnNo+'>.ballsInColumn_Div > div > .ballsInColumn').length;
    if(ballsInColumn>=globalCounter){
    	audioTag.src=Utils.Path+Abacus.numberSoundsJSON[globalCounter*Abacus.StartNoOfLevel];
    	audioTag.play();
    	$('#column'+columnNo+'>.ballsInColumn_Div > div > .ballNo'+globalCounter).addClass("zoomIn");
    	globalCounter++;
    	timerForFunCall_CountBalls2=setTimeout(function(){
      						   		Abacus.CountBallsInColumn(columnNo);
      						   	},1570);
  	}
  	else{
    	globalCounter=1;
    	if(columnNo==10){
    		$('#column'+columnNo+'>.ballsInColumn_Div').hide();
       		$('#column'+columnNo+'>.BallForRoundup > div > img').css("width",""+($(".ballsInColumn").width()+15)+"%");
      		$('#column'+columnNo+'>.BallForRoundup').show();
  		}
  		timerForFunCall_CountBalls2=setTimeout(function(){
			  		Abacus.selectRandomNumberFromRange();
       	},800);
  	}
}

Abacus.readText=function()
{
	document.getElementById('playSound').src=Utils.Path+Abacus.numberSoundsJSON[Abacus.randomNumber];
	document.getElementById('playSound').play();
}